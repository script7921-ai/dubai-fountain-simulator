Dubai Fountain Digital Twin — релиз v2.0.1 (fix: бесконечный рост графика)

Запуск в Termux:
  pkg install -y python
  bash run.sh            # затем открыть http://localhost:8080
Порт меняется: PORT=9000 bash run.sh
